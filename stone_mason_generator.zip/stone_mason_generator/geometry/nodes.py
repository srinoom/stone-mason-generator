import math

print("===== NODES.PY VERSION 3 =====")

from .graph import NodeGraph


def build_basic_nodes(group):

    graph = NodeGraph(group)

    graph.clear()

    group_input = graph.input()

    transform = graph.transform()

    mesh_to_points = graph.mesh_to_points()

    cube = graph.cube()

    instance = graph.instance_on_points()

    realize = graph.realize_instances()

    group_output = graph.output()

    transform.inputs["Rotation"].default_value = (
        0.0,
        0.0,
        math.radians(10),
    )

    graph.link(
        group_input.outputs["Geometry"],
        transform.inputs["Geometry"],
    )

    graph.link(
        transform.outputs["Geometry"],
        mesh_to_points.inputs["Mesh"],
    )

    graph.link(
        mesh_to_points.outputs["Points"],
        instance.inputs["Points"],
    )

    graph.link(
        cube.outputs["Mesh"],
        instance.inputs["Instance"],
    )

    graph.link(
        instance.outputs["Instances"],
        realize.inputs["Geometry"],
    )

    graph.link(
        realize.outputs["Geometry"],
        group_output.inputs["Geometry"],
    )

    print("[SMG] Scatter graph created")
    